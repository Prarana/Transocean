define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onTouchEnd defined for imgLogout **/
    AS_Image_a7f05ecfd4b14902b93654e1795ec44c: function AS_Image_a7f05ecfd4b14902b93654e1795ec44c(eventobject, x, y) {
        var self = this;
        this.doLogout();
    }
});