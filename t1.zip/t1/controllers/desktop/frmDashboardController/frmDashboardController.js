define({ 

 //Type your controller code here 
 doLogout : function(){
    var navToCreateEvent = new kony.mvc.Navigation("frmLogin");
		navToCreateEvent.navigate();
  }
 });