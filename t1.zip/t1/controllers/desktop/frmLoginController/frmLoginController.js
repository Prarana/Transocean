define({ 

 //Type your controller code here 
  doUserLogin : function(username,password){
      this.username = username;
      this.password = password;
      if(username === null || username === "" || password === null || password === ""){
        this.alert("Username or Password should not be Empty");
        return;
      }else{
        if(username === "David Cohen" && password === "password"){
        //this.view.lblName.text = this.username;
        var navToCreateEvent = new kony.mvc.Navigation("frmDashboard");
		navToCreateEvent.navigate();
        }
      }
  }

 });