define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for btnSignIn **/
    AS_Button_d70123609e1a436e82f2bb1bb56ff4a0: function AS_Button_d70123609e1a436e82f2bb1bb56ff4a0(eventobject) {
        var self = this;
        this.doUserLogin(this.view.txtUserName.text, this.view.txtPassword.text);
    }
});