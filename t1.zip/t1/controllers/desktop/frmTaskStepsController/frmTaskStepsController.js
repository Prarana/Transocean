define({ 

 //Type your controller code here 
  initTaskSteps : function(){
    this.bindEvents();
  },
  bindEvents : function(){
    this.view.btnContinue.onClick = this.onClickContinue;
    this.view.flxMakeUp.onClick = this.onClickMakeUp;
    this.view.flxChangeHandling.onClick = this.onChangeHandling;
    this.view.flxRunCasing.onClick = this.onRunCasting;
    this.view.flxRunCasingHole.onClick = this.onRunCastingHole;
    this.view.flxMakeUpHanger.onClick = this.onMakeUpHanger;
  },
  	onClickMakeUp : function(){
      this.view.flxHighlight.width = "60%";
      this.view.flxMakeUp.skin = "sknFlxDarkGreyBorder";
      this.view.imgCheck1.src = "checked.png";
      this.view.btnContinue.isVisible = true;
    },
  	onChangeHandling : function(){
      this.view.flxHighlight.width = "60%";
      this.view.flxChangeHandling.skin = "sknFlxDarkGreyBorder";
      this.view.imgCheck2.src = "checked.png";
      this.view.btnContinue.isVisible = true;
    },
    onRunCasting : function(){
      this.view.flxHighlight.width = "60%";
      this.view.flxRunCasing.skin = "sknFlxDarkGreyBorder";
      this.view.imgCheck3.src = "checked.png";
      this.view.btnContinue.isVisible = true;
    },	
	onRunCastingHole : function(){
      this.view.flxHighlight.width = "60%";
      this.view.flxRunCasingHole.skin = "sknFlxDarkGreyBorder";
      this.view.imgCheck4.src = "checked.png";
      this.view.btnContinue.isVisible = true;
    },
	onMakeUpHanger : function(){
      this.view.flxHighlight.width = "60%";
      this.view.flxMakeUpHanger.skin = "sknFlxDarkGreyBorder";
      this.view.imgCheck5.src = "checked.png";
      this.view.btnContinue.isVisible = true;
    },
	onClickContinue : function(){
      //this.view.flxHighlight.width = ""
    }
 });