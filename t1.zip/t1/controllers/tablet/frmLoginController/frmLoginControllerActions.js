define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for btnSignIn **/
    AS_Button_e89f82fa78d744fbac54d100085b0d86: function AS_Button_e89f82fa78d744fbac54d100085b0d86(eventobject) {
        var self = this;
        this.doUserLogin(this.view.txtUserName.text, this.view.txtPassword.text);
    }
});