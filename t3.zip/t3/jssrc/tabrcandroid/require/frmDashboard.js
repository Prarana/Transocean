define("frmDashboard", function() {
    return function(controller) {
        function addWidgetsfrmDashboard() {
            this.setDefaultUnit(kony.flex.DP);
            var flxImgBg = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxImgBg",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFrmImgBg",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxImgBg.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "CopysknFlxBlueBg0e1f4852fb3ba4a",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "12%",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0%",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var imgTransocean = new kony.ui.Image2({
                "height": "100%",
                "id": "imgTransocean",
                "isVisible": true,
                "left": "2%",
                "skin": "slImage",
                "src": "transocean_logo_white.png",
                "top": "5%",
                "width": "18%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblName = new kony.ui.Label({
                "centerY": "70%",
                "height": "100%",
                "id": "lblName",
                "isVisible": true,
                "right": "12%",
                "skin": "sknLblwhite100",
                "text": "David Cohen",
                "textStyle": {
                    "letterSpacing": 0,
                    "strikeThrough": false
                },
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false
            });
            var imgPerson = new kony.ui.Image2({
                "centerY": "70%",
                "height": "55%",
                "id": "imgPerson",
                "isVisible": true,
                "right": "6%",
                "skin": "slImage",
                "src": "mask.png",
                "top": "5%",
                "width": "6%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgLogout = new kony.ui.Image2({
                "centerY": "70%",
                "height": "100%",
                "id": "imgLogout",
                "isVisible": true,
                "onTouchEnd": controller.AS_Image_a7f05ecfd4b14902b93654e1795ec44c,
                "right": "3%",
                "skin": "slImage",
                "src": "power.png",
                "top": "5%",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxHeader.add(imgTransocean, lblName, imgPerson, imgLogout);
            var flzHorizontal = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "94%",
                "id": "flzHorizontal",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "2%",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flzHorizontal.setDefaultUnit(kony.flex.DP);
            var flxoptions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxoptions",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "1%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "12%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxoptions.setDefaultUnit(kony.flex.DP);
            var flxHome = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "16%",
                "id": "flxHome",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknFlxYellowBg",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxHome.setDefaultUnit(kony.flex.DP);
            var imgHome = new kony.ui.Image2({
                "centerY": "45%",
                "height": "38%",
                "id": "imgHome",
                "isVisible": true,
                "left": "0%",
                "skin": "slImage",
                "src": "home.png",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblHome = new kony.ui.Label({
                "height": "20%",
                "id": "lblHome",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblwhite100",
                "text": "Home",
                "textStyle": {
                    "letterSpacing": 0,
                    "strikeThrough": false
                },
                "top": "6dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false
            });
            flxHome.add(imgHome, lblHome);
            var flxTaskSteps = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "16%",
                "id": "flxTaskSteps",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlx4B4E53Bg",
                "top": "1%",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxTaskSteps.setDefaultUnit(kony.flex.DP);
            var imgTaskSteps = new kony.ui.Image2({
                "centerY": "45%",
                "height": "38%",
                "id": "imgTaskSteps",
                "isVisible": true,
                "left": "0%",
                "skin": "slImage",
                "src": "tasksteps.png",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTaskSteps = new kony.ui.Label({
                "height": "20%",
                "id": "lblTaskSteps",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblwhite100",
                "text": "Task Steps",
                "textStyle": {
                    "letterSpacing": 0,
                    "strikeThrough": false
                },
                "top": "6dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false
            });
            flxTaskSteps.add(imgTaskSteps, lblTaskSteps);
            var flxlogs = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "16%",
                "id": "flxlogs",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlx4B4E53Bg",
                "top": "1%",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxlogs.setDefaultUnit(kony.flex.DP);
            var imgLogs = new kony.ui.Image2({
                "height": "38%",
                "id": "imgLogs",
                "isVisible": true,
                "left": "0%",
                "skin": "slImage",
                "src": "logs.png",
                "top": "18%",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLogs = new kony.ui.Label({
                "height": "20%",
                "id": "lblLogs",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblwhite100",
                "text": "Logs",
                "textStyle": {
                    "letterSpacing": 0,
                    "strikeThrough": false
                },
                "top": "6dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false
            });
            flxlogs.add(imgLogs, lblLogs);
            var flxHandOvers = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "16%",
                "id": "flxHandOvers",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlx4B4E53Bg",
                "top": "1%",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxHandOvers.setDefaultUnit(kony.flex.DP);
            var imgHandOvers = new kony.ui.Image2({
                "height": "38%",
                "id": "imgHandOvers",
                "isVisible": true,
                "left": "0%",
                "skin": "slImage",
                "src": "hands.png",
                "top": "18%",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblHandOvers = new kony.ui.Label({
                "height": "20%",
                "id": "lblHandOvers",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblwhite100",
                "text": "Handovers",
                "textStyle": {
                    "letterSpacing": 0,
                    "strikeThrough": false
                },
                "top": "6dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false
            });
            flxHandOvers.add(imgHandOvers, lblHandOvers);
            var flxDailyInstructions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "16%",
                "id": "flxDailyInstructions",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlx4B4E53Bg",
                "top": "1%",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxDailyInstructions.setDefaultUnit(kony.flex.DP);
            var imgDailyInstructions = new kony.ui.Image2({
                "height": "38%",
                "id": "imgDailyInstructions",
                "isVisible": true,
                "left": "0%",
                "skin": "slImage",
                "src": "instruction.png",
                "top": "18%",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDailyInstructions = new kony.ui.Label({
                "height": "20%",
                "id": "lblDailyInstructions",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblwhite100",
                "text": "Daily Instructions",
                "textStyle": {
                    "letterSpacing": 0,
                    "strikeThrough": false
                },
                "top": "6dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false
            });
            flxDailyInstructions.add(imgDailyInstructions, lblDailyInstructions);
            var flxDailyChecklists = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "16%",
                "id": "flxDailyChecklists",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknFlx4B4E53Bg",
                "top": "1%",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxDailyChecklists.setDefaultUnit(kony.flex.DP);
            var imgChecklists = new kony.ui.Image2({
                "height": "38%",
                "id": "imgChecklists",
                "isVisible": true,
                "left": "0%",
                "skin": "slImage",
                "src": "checklists.png",
                "top": "18%",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblChecklists = new kony.ui.Label({
                "height": "20%",
                "id": "lblChecklists",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblwhite100",
                "text": "Daily Checklist",
                "textStyle": {
                    "letterSpacing": 0,
                    "strikeThrough": false
                },
                "top": "6dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false
            });
            flxDailyChecklists.add(imgChecklists, lblChecklists);
            flxoptions.add(flxHome, flxTaskSteps, flxlogs, flxHandOvers, flxDailyInstructions, flxDailyChecklists);
            var flxSignIn = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxSignIn",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "1%",
                "isModalContainer": false,
                "skin": "sknFlxWhiteBg",
                "top": "0dp",
                "width": "84%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxSignIn.setDefaultUnit(kony.flex.DP);
            var flxYellowHome = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "2%",
                "id": "flxYellowHome",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "3%",
                "isModalContainer": false,
                "skin": "sknFlxYellowBg",
                "top": "0dp",
                "width": "9%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxYellowHome.setDefaultUnit(kony.flex.DP);
            flxYellowHome.add();
            var lblSignIn = new kony.ui.Label({
                "id": "lblSignIn",
                "isVisible": true,
                "left": "3%",
                "skin": "sknLbl4B4E53180",
                "text": "HOME",
                "textStyle": {
                    "letterSpacing": 0,
                    "strikeThrough": false
                },
                "top": "2%",
                "width": "40%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false
            });
            var lblOpenWorkPack = new kony.ui.Label({
                "id": "lblOpenWorkPack",
                "isVisible": true,
                "left": "3%",
                "skin": "sknLbl4B4E53100Bold",
                "text": "Open Work Pack",
                "textStyle": {
                    "letterSpacing": 0,
                    "strikeThrough": false
                },
                "top": "6%",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false
            });
            var flxList = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "9%",
                "id": "flxList",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "2%",
                "width": "97%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxList.setDefaultUnit(kony.flex.DP);
            var listBoxRun = new kony.ui.ListBox({
                "focusSkin": "defListBoxFocus",
                "height": "100%",
                "id": "listBoxRun",
                "isVisible": true,
                "left": "0dp",
                "masterData": [
                    ["lb1", "Run Intermediate Casing and Make up Hanger"],
                    ["lb2", "Run Intermediate Casing and Make up Hanger"],
                    ["lb3", "Run Intermediate Casing and Make up Hanger"]
                ],
                "skin": "CopydefListBoxNormal0j04d7518937d4b",
                "top": "0dp",
                "width": "80%",
                "zIndex": 1,
                "blur": {
                    "enabled": false,
                    "value": 0
                }
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "applySkinsToPopup": true,
                "dropDownImage": "chevron_down.png",
                "placeholder": "Please Select",
                "viewType": constants.LISTBOX_VIEW_TYPE_LISTVIEW
            });
            var btnGo = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "100%",
                "id": "btnGo",
                "isVisible": true,
                "left": "3%",
                "skin": "btn4B4E53Bg",
                "text": "GO",
                "top": "0dp",
                "width": "10%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxList.add(listBoxRun, btnGo);
            var CopyflxLine0j17ca5c412cf4d = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "CopyflxLine0j17ca5c412cf4d",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "3%",
                "isModalContainer": false,
                "skin": "sknFlx70707026Border",
                "top": "0%",
                "width": "78%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            CopyflxLine0j17ca5c412cf4d.setDefaultUnit(kony.flex.DP);
            CopyflxLine0j17ca5c412cf4d.add();
            var lblWorkPackAssigned = new kony.ui.Label({
                "id": "lblWorkPackAssigned",
                "isVisible": true,
                "left": "3%",
                "skin": "sknLbl4B4E53100Bold",
                "text": "Work Pack Assigned",
                "textStyle": {
                    "letterSpacing": 0,
                    "strikeThrough": false
                },
                "top": "5%",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false
            });
            var flxLine = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxLine",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "3%",
                "isModalContainer": false,
                "skin": "sknFlx70707026Border",
                "top": "2%",
                "width": "90%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxLine.setDefaultUnit(kony.flex.DP);
            flxLine.add();
            var flxDones = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "10%",
                "id": "flxDones",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "7%",
                "width": "97%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxDones.setDefaultUnit(kony.flex.DP);
            var flxCleanout = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxCleanout",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "skn68686878Border",
                "top": "0%",
                "width": "28%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxCleanout.setDefaultUnit(kony.flex.DP);
            var flxCleanOutCheckbox = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxCleanOutCheckbox",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxGreenBg",
                "top": "0dp",
                "width": "20%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxCleanOutCheckbox.setDefaultUnit(kony.flex.DP);
            var imgCleanCheckbox = new kony.ui.Image2({
                "height": "100%",
                "id": "imgCleanCheckbox",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "done.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCleanOutCheckbox.add(imgCleanCheckbox);
            var lblCleanOut = new kony.ui.Label({
                "height": "30dp",
                "id": "lblCleanOut",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLbl4B4E53100",
                "text": "Cleanout Run",
                "textStyle": {
                    "letterSpacing": 0,
                    "strikeThrough": false
                },
                "top": "16dp",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false
            });
            flxCleanout.add(flxCleanOutCheckbox, lblCleanOut);
            var flxDrill = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxDrill",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "4%",
                "isModalContainer": false,
                "skin": "skn68686878Border",
                "top": "0%",
                "width": "35%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxDrill.setDefaultUnit(kony.flex.DP);
            var flxDrillCheckbox = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxDrillCheckbox",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxGreenBg",
                "top": "0dp",
                "width": "20%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxDrillCheckbox.setDefaultUnit(kony.flex.DP);
            var imgDrillCheckbox = new kony.ui.Image2({
                "height": "100%",
                "id": "imgDrillCheckbox",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "done.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDrillCheckbox.add(imgDrillCheckbox);
            var lblDrill = new kony.ui.Label({
                "height": "30dp",
                "id": "lblDrill",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLbl4B4E53100",
                "text": "Drill 12-1/2\" Hole Section",
                "textStyle": {
                    "letterSpacing": 0,
                    "strikeThrough": false
                },
                "top": "16dp",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false
            });
            flxDrill.add(flxDrillCheckbox, lblDrill);
            flxDones.add(flxCleanout, flxDrill);
            flxSignIn.add(flxYellowHome, lblSignIn, lblOpenWorkPack, flxList, CopyflxLine0j17ca5c412cf4d, lblWorkPackAssigned, flxLine, flxDones);
            flzHorizontal.add(flxoptions, flxSignIn);
            flxMain.add(flxHeader, flzHorizontal);
            flxImgBg.add(flxMain);
            this.add(flxImgBg);
        };
        return [{
            "addWidgets": addWidgetsfrmDashboard,
            "enabledForIdleTimeout": false,
            "id": "frmDashboard",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "slForm",
            "info": {
                "kuid": "b2655d1ceead446a870a2b52c591e828"
            }
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_LANDSCAPE,
            "layoutType": kony.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "footerOverlap": false,
            "headerOverlap": false,
            "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
            "retainScrollPosition": false,
            "titleBar": true,
            "titleBarSkin": "slTitleBar",
            "windowSoftInputMode": constants.FORM_ADJUST_PAN
        }]
    }
});