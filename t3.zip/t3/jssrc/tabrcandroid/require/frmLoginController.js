define("userfrmLoginController", {
    //Type your controller code here 
    doUserLogin: function(username, password) {
        this.username = username;
        this.password = password;
        if (username === null || username === "" || password === null || password === "") {
            this.alert("Username or Password should not be Empty");
            return;
        } else {
            if (username === "David Cohen" && password === "password") {
                //this.view.lblName.text = this.username;
                var navToCreateEvent = new kony.mvc.Navigation("frmDashboard");
                navToCreateEvent.navigate();
            }
        }
    }
});
define("frmLoginControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for btnSignIn **/
    AS_Button_e89f82fa78d744fbac54d100085b0d86: function AS_Button_e89f82fa78d744fbac54d100085b0d86(eventobject) {
        var self = this;
        this.doUserLogin(this.view.txtUserName.text, this.view.txtPassword.text);
    }
});
define("frmLoginController", ["userfrmLoginController", "frmLoginControllerActions"], function() {
    var controller = require("userfrmLoginController");
    var controllerActions = ["frmLoginControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
